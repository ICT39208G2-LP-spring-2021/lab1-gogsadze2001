<?php 
foreach ($_SERVER as $value) {
    echo $value.'<br>';
  }
?>